﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaskManagement.Models.Contracts
{
    public interface ITime
    {
        DateTime Time { get; }
    }
}
