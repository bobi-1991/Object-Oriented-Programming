﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaskManagement.Models.Enums
{
    public enum Priority
    {
        Low,
        Medium,
        High
    }
}
