﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaskManagement.Models.Enums
{
    public enum BugSeverity
    {
        Minor,
        Major,
        Critical
    }
}
