﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaskManagement.Core.Contracts
{
    public interface IEngine
    {
        void Start();
    }
}
