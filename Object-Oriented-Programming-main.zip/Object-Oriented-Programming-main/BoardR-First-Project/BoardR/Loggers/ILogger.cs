﻿namespace BoardR.Loggers
{
    public interface ILogger
    {
        void Log(string value);

    }
}
