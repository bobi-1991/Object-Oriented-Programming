﻿namespace BoardR
{
    public enum Status
    {
        Open,
        ToDo,
        InProgress,
        Done,
        Verified
    }
}
